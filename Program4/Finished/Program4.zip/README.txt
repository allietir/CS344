COMMENT: All testing was done on the school servers
and it worked, but I transferred them from the servers
to my local machine in order to turn it in. If anything is broken,
try dos2unix. Thanks!